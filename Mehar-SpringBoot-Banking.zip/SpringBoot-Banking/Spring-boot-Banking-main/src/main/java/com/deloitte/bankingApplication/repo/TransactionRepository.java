package com.deloitte.bankingApplication.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.deloitte.bankingApplication.entity.Transaction;

import java.util.List;

public interface TransactionRepository extends JpaRepository<Transaction, Long> {


	List<Transaction> findBySourceAccountIdOrderByInitiationDate(long id);
}
