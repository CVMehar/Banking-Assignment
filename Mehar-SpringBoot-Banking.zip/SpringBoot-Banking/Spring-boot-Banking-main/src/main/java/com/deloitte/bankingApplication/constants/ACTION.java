package com.deloitte.bankingApplication.constants;

public enum ACTION {
	DEPOSIT, WITHDRAW
}
